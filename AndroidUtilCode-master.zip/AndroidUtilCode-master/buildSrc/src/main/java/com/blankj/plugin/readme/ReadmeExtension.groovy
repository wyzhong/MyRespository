package com.blankj.plugin.readme

class ReadmeExtension {

    File readmeFile
    File readmeCnFile

}
