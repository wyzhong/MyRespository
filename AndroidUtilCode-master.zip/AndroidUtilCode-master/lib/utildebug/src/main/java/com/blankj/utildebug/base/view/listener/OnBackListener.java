package com.blankj.utildebug.base.view.listener;

/**
 * <pre>
 *     author: blankj
 *     blog  : http://blankj.com
 *     time  : 2019/09/20
 *     desc  :
 * </pre>
 */
public interface OnBackListener {
    void onBack();
}
