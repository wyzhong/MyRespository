package com.blankj.utilcode.util.reflect;

/**
 * <pre>
 *     author: Blankj
 *     blog  : http://blankj.com
 *     time  : 2018/01/12
 *     desc  :
 * </pre>
 */
public class Test1 {
    public static int     S_INT1;
    public static Integer S_INT2;
    public        int     I_INT1;
    public        Integer I_INT2;

    public static Test1 S_DATA;
    public        Test1 I_DATA;
}
