package com.blankj.utilcode.util.reflect;

/**
 * <pre>
 *     author: Blankj
 *     blog  : http://blankj.com
 *     time  : 2018/01/12
 *     desc  :
 * </pre>
 */
public class TestPrivateStaticFinal {
    private static final int     I1 = new Integer(1);
    private static final Integer I2 = new Integer(1);
}
