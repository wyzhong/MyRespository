package com.blankj.common;

import com.blankj.base.BaseApplication;

/**
 * <pre>
 *     author: Blankj
 *     blog  : http://blankj.com
 *     time  : 2019/06/05
 *     desc  : app about common
 * </pre>
 */
public class CommonApplication extends BaseApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
