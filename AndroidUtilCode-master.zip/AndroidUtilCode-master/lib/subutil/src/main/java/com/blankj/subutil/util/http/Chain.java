package com.blankj.subutil.util.http;

public interface Chain {
}
