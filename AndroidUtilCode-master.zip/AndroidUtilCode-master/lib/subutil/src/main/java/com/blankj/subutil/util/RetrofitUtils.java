package com.blankj.subutil.util;

/**
 * <pre>
 *     author: Blankj
 *     blog  : http://blankj.com
 *     time  : 2018/08/25
 *     desc  : utils about retrofit
 * </pre>
 */
public final class RetrofitUtils {

}
