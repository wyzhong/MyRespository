package com.blankj.subutil.util.http;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Headers {

    private Map<String, List<String>> header = new HashMap<>();


}
