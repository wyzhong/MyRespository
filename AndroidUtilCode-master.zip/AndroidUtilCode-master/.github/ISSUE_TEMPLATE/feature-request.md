---
name: Feature request
about: Make AndroidUtilCode more perfect!
labels: help wanted
assignees: Blankj

---

## Describe the feature

A clear and concise description of what the feature is.


## Reference

Hope to give some reference articles, links, code, if any.


## Please delete the current line and the following

Thank you for supporting [AndroidUtilCode](https://github.com/Blankj/AndroidUtilCode).
