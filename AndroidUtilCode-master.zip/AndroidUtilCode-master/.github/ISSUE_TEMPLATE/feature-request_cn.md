---
name: 提交需求
about: 让工具类更健全！
labels: help wanted
assignees: Blankj

---

## 描述需求

简洁地描述下需求。


## 可借鉴的

如果有的话，可以给出一些参考文章、链接、代码


## 请删除当前行及以下内容

感谢支持 [AndroidUtilCode](https://github.com/Blankj/AndroidUtilCode).
