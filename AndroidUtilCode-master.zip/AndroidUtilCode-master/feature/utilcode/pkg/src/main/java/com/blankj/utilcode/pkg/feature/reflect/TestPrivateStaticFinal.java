package com.blankj.utilcode.pkg.feature.reflect;

import android.support.annotation.Keep;

/**
 * <pre>
 *     author: blankj
 *     blog  : http://blankj.com
 *     time  : 2019/09/09
 *     desc  :
 * </pre>
 */
@Keep
public class TestPrivateStaticFinal {
    public static final String STR = "str";
}
