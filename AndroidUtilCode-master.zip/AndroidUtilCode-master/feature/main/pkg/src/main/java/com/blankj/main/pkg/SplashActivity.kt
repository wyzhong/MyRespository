package com.blankj.main.pkg

import com.blankj.common.activity.CommonActivity

class SplashActivity : CommonActivity() {

}